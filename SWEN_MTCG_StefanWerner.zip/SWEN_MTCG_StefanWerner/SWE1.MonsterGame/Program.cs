﻿using SWE.Models;
using System;



TCPServer server = new TCPServer(10001);

server.Start();



