
curl -i -X POST http://localhost:10001/users --header "Content-Type: application/js